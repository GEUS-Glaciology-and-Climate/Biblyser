"""
Biblyser (c) is a bibliometric workflow for evaluating the bib metrics of an 
individual or a group of people (an organisation).

Biblyser is licensed under a MIT License.

You should have received a copy of the license along with this work. If not, 
see <https://choosealicense.com/licenses/mit/>.

BIBLYSER INITIALISATION FILE
This file is needed for the package initialisation.
"""
